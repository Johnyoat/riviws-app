package com.hipromarketing.riviws.ui;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.transition.TransitionInflater;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.hipromarketing.riviws.R;
import com.hipromarketing.riviws.adapters.TrendAdapter;
import com.hipromarketing.riviws.models.Trend;
import com.hipromarketing.riviws.utils.UICreator;
import com.willy.ratingbar.ScaleRatingBar;

import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.hipromarketing.riviws.constants.Constants.getUser;

/**
 * A simple {@link Fragment} subclass.
 */
public class CategoryDetails extends DialogFragment {
    private TrendAdapter adapter;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private AppCompatImageView searchIc;
    private SearchView searchView;
    private AppCompatImageView logo;
    private AppBarLayout appBarToolBar;
    private BottomNavigationView bnv;
    private View foobar;
    private String cls;


    public static CategoryDetails newInstance(String drawable, String head, String type, String commentType) {

        Bundle args = new Bundle();

        CategoryDetails fragment = new CategoryDetails();
        args.putString("banner", drawable);
        args.putString("head", head);
        args.putString("type", type);
        args.putString("commentType", commentType);
        fragment.setArguments(args);
        return fragment;
    }

    public static CategoryDetails newInstance(String drawable, String head, String type, String commentType, String locationUrl, String lng, String lat) {

        Bundle args = new Bundle();

        CategoryDetails fragment = new CategoryDetails();
        args.putString("banner", drawable);
        args.putString("head", head);
        args.putString("type", type);
        args.putString("commentType", commentType);
        args.putString("locationUrl", locationUrl);
        args.putString("lng", lng);
        args.putString("lat", lat);
        fragment.setArguments(args);
        return fragment;
    }

    public CategoryDetails() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.category_details, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final RecyclerView reviewList = view.findViewById(R.id.reviews);
        AppCompatImageView banner = view.findViewById(R.id.banner);
        AppCompatTextView category = view.findViewById(R.id.category);
        final AppCompatImageView bck = view.findViewById(R.id.back);
        AppCompatImageButton send = view.findViewById(R.id.send);
        final ScaleRatingBar rating = view.findViewById(R.id.rating);
        final AppCompatEditText comment = view.findViewById(R.id.comment);
        final View rateView = view.findViewById(R.id.rateLayout);
        final String head;

        getUser();

        AppCompatImageButton closeRateView = rateView.findViewById(R.id.close);

        LinearLayout addReview = view.findViewById(R.id.addReview);
        AppCompatImageView navigate;


        searchIc = view.findViewById(R.id.searchIc);
        searchView = view.findViewById(R.id.search);
        assert getActivity() != null;
        logo = getActivity().findViewById(R.id.logo);
        appBarToolBar = view.findViewById(R.id.app_bar);
        bnv = getActivity().findViewById(R.id.btnNav);
        foobar = getActivity().findViewById(R.id.foobar);
        navigate = view.findViewById(R.id.navigate);


        navigate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                assert getArguments() != null;
                String url = getArguments().getString("locationUrl");
                if (url != null && !url.isEmpty()) {
//                   Intent i = new Intent(Intent.ACTION_VIEW);
//                   i.setData(Uri.parse(url));
//                   startActivity(i);
                    UICreator.getInstance((AppCompatActivity) getActivity()).createDialog(ShowLocation.newInstance(getArguments().getString("lng"), getArguments().getString("lat")), "showDetails");
                }
            }
        });

        foobar.setVisibility(View.GONE);

        searchIc.setVisibility(View.VISIBLE);

        searchIc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchView.setVisibility(View.VISIBLE);
                searchIc.setVisibility(View.GONE);
                logo.setVisibility(View.GONE);
                bck.setVisibility(View.GONE);
                foobar.setVisibility(View.GONE);
                appBarToolBar.setExpanded(false);
                searchView.setIconified(false);
            }
        });


        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                searchView.setVisibility(View.GONE);
                searchIc.setVisibility(View.VISIBLE);
                bck.setVisibility(View.VISIBLE);
                logo.setVisibility(View.VISIBLE);
                foobar.setVisibility(View.GONE);
                return false;
            }
        });


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                if (adapter != null) {
                    adapter.getFilter().filter(s);
                }
                return false;
            }
        });


        KeyboardVisibilityEvent.setEventListener(
                getActivity(),
                new KeyboardVisibilityEventListener() {
                    @Override
                    public void onVisibilityChanged(boolean isOpen) {
                        if (bnv != null) {
                            if (isOpen) {
                                bnv.setVisibility(View.GONE);
                            } else {
                                bnv.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                });


        setSharedElementEnterTransition(TransitionInflater.from(getContext()).inflateTransition(R.transition.transition));


        closeRateView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rateView.setVisibility(View.GONE);
                reviewList.setVisibility(View.VISIBLE);
            }
        });

        addReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rateView.setVisibility(View.VISIBLE);
                reviewList.setVisibility(View.GONE);

            }
        });

        bck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fm = getActivity().getSupportFragmentManager();
                if (fm.getBackStackEntryCount() == 0) {
                    fm.beginTransaction()
                            .replace(R.id.homeContainer, Home.newInstance(), "home")
                            .commit();
                    dismissAllowingStateLoss();

                } else if (getCls() != null) {
                    if (getCls().equalsIgnoreCase("close")) {
                        dismissAllowingStateLoss();
                    }
                } else {
                    fm.popBackStack();

                }
            }
        });

        Bundle args = getArguments();
        assert args != null;
        head = args.getString("head");
        category.setText(head);


        if (Objects.requireNonNull(args.getString("type")).equalsIgnoreCase("company")) {
            addReview.setVisibility(View.VISIBLE);
            navigate.setVisibility(View.VISIBLE);
            assert getContext() != null;
            Glide.with(getContext()).load(args.get("banner")).into(banner);
            loadData(reviewList, head, "company");

        } else {
            assert head != null && getActivity() != null;
            loadData(reviewList, head.toLowerCase(), "commentType");
            banner.setImageDrawable(getActivity().getResources().getDrawable(Integer.valueOf(args.getString("banner"))));
        }


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DocumentReference ref = db.collection("riviws").document();
                Trend trend = new Trend();

                trend.setCompany(head);
                assert comment.getText() != null;
                trend.setComment(comment.getText().toString());
                trend.setDate(String.valueOf(System.currentTimeMillis()));
                trend.setCommentType(getArguments().getString("commentType"));
                trend.setRating(String.valueOf(rating.getRating()));
                trend.setId(ref.getId());
                trend.setUser(getUser());

                rateView.setVisibility(View.GONE);
                reviewList.setVisibility(View.VISIBLE);
                ref.set(trend);

            }
        });

    }

    private void loadData(final RecyclerView reviewList, String head, String field) {
        db.collection("riviws")
                .orderBy("date", Query.Direction.DESCENDING)
                .whereEqualTo(field, head).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@javax.annotation.Nullable QuerySnapshot queryDocumentSnapshots, @javax.annotation.Nullable FirebaseFirestoreException e) {
                if (queryDocumentSnapshots != null) {
                    List<Trend> filtered = new ArrayList<>();
                    for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                        filtered.add(snapshot.toObject(Trend.class));
                    }
                    setRecyclerView(reviewList, filtered);
                }
            }
        });
    }

    private void setRecyclerView(RecyclerView reviewList, List<Trend> trends) {
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getContext(), R.anim.layout_fall);
        adapter = new TrendAdapter(trends, getContext(), getActivity());
        reviewList.setLayoutManager(new LinearLayoutManager(getContext()));
        reviewList.setAdapter(adapter);
        reviewList.setHasFixedSize(true);
        reviewList.setDrawingCacheEnabled(true);
        reviewList.setItemViewCacheSize(20);
        reviewList.setLayoutAnimation(animation);
    }

    @Override
    public void onStop() {
        super.onStop();
        foobar.setVisibility(View.VISIBLE);
    }


    public String getCls() {
        return cls;
    }

    public void setCls(String cls) {
        this.cls = cls;
    }
}
