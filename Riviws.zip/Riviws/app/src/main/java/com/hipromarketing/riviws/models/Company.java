package com.hipromarketing.riviws.models;

import java.util.List;

public class Company {
    private String companyID;
    private String companyName;
    private String companyProfileUrl;
    private String generalRating;
    private List<String> reviews;

    public String getCompanyID() {
        return companyID;
    }

    public void setCompanyID(String companyID) {
        this.companyID = companyID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyProfileUrl() {
        return companyProfileUrl;
    }

    public void setCompanyProfileUrl(String companyProfileUrl) {
        this.companyProfileUrl = companyProfileUrl;
    }

    public String getGeneralRating() {
        return generalRating;
    }

    public void setGeneralRating(String generalRating) {
        this.generalRating = generalRating;
    }

    public List<String> getReviews() {
        return reviews;
    }

    public void setReviews(List<String> reviews) {
        this.reviews = reviews;
    }
}
