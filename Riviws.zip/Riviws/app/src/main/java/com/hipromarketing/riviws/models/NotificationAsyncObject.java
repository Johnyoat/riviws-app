package com.hipromarketing.riviws.models;

public class NotificationAsyncObject {
    private NotificationObject notificationObject;
    private String title;
}
