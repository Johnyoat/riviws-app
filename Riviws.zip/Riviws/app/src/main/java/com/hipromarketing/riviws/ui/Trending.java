package com.hipromarketing.riviws.ui;


import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.ProgressBar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.hipromarketing.riviws.R;
import com.hipromarketing.riviws.adapters.TrendAdapter;
import com.hipromarketing.riviws.models.Trend;

import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener;

import java.util.ArrayList;
import java.util.List;

import static com.hipromarketing.riviws.constants.Constants.RECYCLER_LOAD_TIME;

/**
 * A simple {@link Fragment} subclass.
 */
public class Trending extends DialogFragment {
    private RecyclerView trendingList;
    private TrendAdapter adapter;
    private Parcelable listSate;
    private ProgressBar progressBar;
    private View btnNav;

    public static Trending newInstance(String filter) {

        Bundle args = new Bundle();

        Trending fragment = new Trending();
        args.putString("filter", filter);
        fragment.setArguments(args);
        return fragment;
    }


    public Trending() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.trending, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        AppCompatEditText search = view.findViewById(R.id.search);

        assert getActivity() != null;
        btnNav = getActivity().findViewById(R.id.btnNav);

        trendingList = view.findViewById(R.id.trendList);
        progressBar = view.findViewById(R.id.progress);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (getArguments() != null) {
            String key = getArguments().getString("filter");
            Query query = db.collection("riviws").orderBy("date", Query.Direction.DESCENDING);
            if (key != null) {
                switch (key) {
                    case "default":
                        queryListener(query);
                        break;
                    case "user_filter":
                        assert user != null;
                        queryListener(query.whereEqualTo("user.uid", user.getUid()));
                        break;
                    default:
                        break;
                }
            }
        }


        final ViewGroup.MarginLayoutParams margins = (ViewGroup.MarginLayoutParams) trendingList.getLayoutParams();

        KeyboardVisibilityEvent.setEventListener(
                getActivity(),
                new KeyboardVisibilityEventListener() {
                    @Override
                    public void onVisibilityChanged(boolean isOpen) {
                        if (btnNav != null) {
                            if (isOpen) {
                                bottomNavigationVisibilityControl(View.GONE);
                                margins.setMargins(0, 0, 0, 0);
                                trendingList.setLayoutParams(margins);
                            } else {
                                bottomNavigationVisibilityControl(View.VISIBLE);
                                margins.setMargins(0, 0, 0, 60);
                                trendingList.setLayoutParams(margins);
                            }
                        }
                    }
                });


        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence != null & adapter != null) {
                    adapter.getFilter().filter(charSequence);
                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence != null & adapter != null) {
                    adapter.getFilter().filter(charSequence);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void populateTrendList(final List<Trend> trends) {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.GONE);
                trendingList.setVisibility(View.VISIBLE);
                LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getContext(), R.anim.layout_fall);
                LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                adapter = new TrendAdapter(trends, getContext(), getActivity());
                trendingList.setLayoutManager(mLayoutManager);
                trendingList.setAdapter(adapter);
                trendingList.setHasFixedSize(true);
                trendingList.setItemViewCacheSize(20);
                trendingList.setDrawingCacheEnabled(true);
                trendingList.setLayoutAnimation(animation);
                assert trendingList.getLayoutManager() != null;
                listSate = trendingList.getLayoutManager().onSaveInstanceState();
                trendingList.getLayoutManager().onRestoreInstanceState(listSate);
                adapter.notifyItemChanged(0, adapter.getItemCount());
            }
        }, RECYCLER_LOAD_TIME);
    }

    private void bottomNavigationVisibilityControl(int gone) {
        btnNav.setVisibility(gone);
    }

    private void queryListener(Query query) {
        query.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@javax.annotation.Nullable QuerySnapshot queryDocumentSnapshots, @javax.annotation.Nullable FirebaseFirestoreException e) {
                if (queryDocumentSnapshots != null) {
                    final List<Trend> list = new ArrayList<>();
                    for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                        list.add(snapshot.toObject(Trend.class));
                    }
                    if (isVisible() && getContext() != null){
                        populateTrendList(list);
                    }
                }
            }
        });

    }
}
