package com.hipromarketing.riviws.models;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

public class Trend  implements Parcelable{
    private String id;
    private String companyID ="";
    private String comment ="";
    private String imageUrl ="";
    private String company ="";
    private String date ="";
    private String rating ="0";
    private String commentType="";
    private String lng = "";
    private String lat = "";
    private User user;
    private List<Reply> replies = new ArrayList<>();
    private List<User> likes = new ArrayList<>();
    private String localcionUrl = "";



    public Trend(){

    }

    protected Trend(Parcel in) {
        id = in.readString();
        companyID = in.readString();
        comment = in.readString();
        imageUrl = in.readString();
        company = in.readString();
        date = in.readString();
        rating = in.readString();
        lng = in.readString();
        lat = in.readString();
        commentType = in.readString();
        localcionUrl = in.readString();
        user = in.readParcelable(User.class.getClassLoader());
        likes = in.createTypedArrayList(User.CREATOR);
    }

    public static final Creator<Trend> CREATOR = new Creator<Trend>() {
        @Override
        public Trend createFromParcel(Parcel in) {
            return new Trend(in);
        }

        @Override
        public Trend[] newArray(int size) {
            return new Trend[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCompanyID() {
        return companyID;
    }

    public void setCompanyID(String companyID) {
        this.companyID = companyID;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getCommentType() {
        return commentType;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLocalcionUrl() {
        return localcionUrl;
    }

    public void setLocalcionUrl(String localcionUrl) {
        this.localcionUrl = localcionUrl;
    }

    public void setCommentType(String commentType) {
        this.commentType = commentType;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Reply> getReplies() {
        return replies;
    }

    public void setReplies(List<Reply> replies) {
        this.replies = replies;
    }

    public List<User> getLikes() {
        return likes;
    }

    public void setLikes(List<User> likes) {
        this.likes = likes;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id);
        parcel.writeString(companyID);
        parcel.writeString(comment);
        parcel.writeString(imageUrl);
        parcel.writeString(company);
        parcel.writeString(date);
        parcel.writeString(rating);
        parcel.writeString(commentType);
        parcel.writeParcelable(user, i);
        parcel.writeTypedList(likes);
        parcel.writeString(lng);
        parcel.writeString(lat);
        parcel.writeString(localcionUrl);
    }
}
