package com.hipromarketing.riviws.ui;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hipromarketing.riviws.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Welcome extends Fragment {

    public static Welcome newInstance() {
        
        Bundle args = new Bundle();
        
        Welcome fragment = new Welcome();
        fragment.setArguments(args);
        return fragment;
    }


    public Welcome() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.welocme, container, false);
    }

}
