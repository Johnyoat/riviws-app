package com.hipromarketing.riviws.ui;


import android.app.Fragment;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.bumptech.glide.Glide;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.hipromarketing.riviws.R;
import com.hipromarketing.riviws.adapters.RepliesAdapter;
import com.hipromarketing.riviws.adapters.TrendAdapter;
import com.hipromarketing.riviws.models.Reply;
import com.hipromarketing.riviws.models.Trend;
import com.hipromarketing.riviws.models.User;
import com.hipromarketing.riviws.utils.PostObjectHelper;
import com.hipromarketing.riviws.utils.UICreator;
import com.willy.ratingbar.ScaleRatingBar;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.hipromarketing.riviws.constants.Constants.COMMENT;
import static com.hipromarketing.riviws.constants.Constants.LIKED;
import static com.hipromarketing.riviws.constants.Constants.getUser;

/**
 * A simple {@link Fragment} subclass.
 */
public class CommentDetails extends DialogFragment {
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private View navigationBtn;
    LinearLayout profileInfo;
    Trend trend;
    AppCompatTextView likesCount;
    AppCompatTextView likesMessage;
    AppCompatImageView likeIc;
    AppCompatEditText comment;
    RecyclerView replyList;
    boolean[] like = {false};
    String id;
    AppCompatImageView bck;
    AppCompatImageView imageView;
    AppCompatTextView message;
    AppCompatTextView user;
    AppCompatTextView company;
    CircleImageView userProfile;
    ScaleRatingBar rating;
    AppCompatImageButton send;
    FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
    ProgressBar progressBar;
    LinearLayout body;

    public static CommentDetails newInstance(String id) {
        Bundle args = new Bundle();
        CommentDetails fragment = new CommentDetails();
        args.putString("id", id);
        fragment.setArguments(args);
        return fragment;
    }

    public static CommentDetails newInstance(Trend trend) {

        Bundle args = new Bundle();

        CommentDetails fragment = new CommentDetails();
        args.putParcelable("trend", trend);
        fragment.setArguments(args);
        return fragment;
    }


    public CommentDetails() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.comment_deatils, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        bck = view.findViewById(R.id.back);
        imageView = view.findViewById(R.id.banner);
        message = view.findViewById(R.id.message);
        user = view.findViewById(R.id.user);
        company = view.findViewById(R.id.company);
        userProfile = view.findViewById(R.id.userProfile);
        rating = view.findViewById(R.id.rating);
        send = view.findViewById(R.id.send);
        likesCount = view.findViewById(R.id.likesCount);
        likesMessage = view.findViewById(R.id.likesMessage);
        comment = view.findViewById(R.id.comment);
        replyList = view.findViewById(R.id.replies);
        navigationBtn = getActivity().findViewById(R.id.btnNav);
        profileInfo = view.findViewById(R.id.profileInfo);
        likeIc = view.findViewById(R.id.likeIc);
        progressBar = view.findViewById(R.id.progress);
        body = view.findViewById(R.id.body);

        body.setVisibility(View.GONE);


        if (getArguments() != null) {
            trend = getArguments().getParcelable("trend");
            id = getArguments().getString("id");
        }

        getUser();


        navigationBtn.setVisibility(View.GONE);

        if (getArguments() != null && trend != null) {

            setUpTrend(trend);
            setUpPageWithTrend(trend.getId());

        } else if (id != null) {
            progressBar.setVisibility(View.GONE);
            body.setVisibility(View.VISIBLE);
            setUpPageWithTrend(id);
        }


        likesMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UICreator.getInstance((AppCompatActivity) getActivity()).createDialog(LikedPage.newInstance(trend.getId()), "toLikePage");
            }
        });

        likeIc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                likeCounter(trend);
            }
        });


        bck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismissAllowingStateLoss();
                navigationBtn.setVisibility(View.VISIBLE);
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (!comment.getText().toString().isEmpty()) {

                    Reply reply = new Reply();
                    reply.setDate(String.valueOf(System.currentTimeMillis()));
                    reply.setUser(getUser());
                    reply.setComment(comment.getText().toString());

                    Map<String, Object> replies = new ObjectMapper().convertValue(reply, Map.class);

                    PostObjectHelper.getInstance().setAction(COMMENT, trend.getId(), trend.getCompany(), trend.getUser().getUid());

                    db.collection("riviws").document(trend.getId()).update("replies", FieldValue.arrayUnion(replies));
                    comment.setText("");

                    navigationBtn.setVisibility(View.VISIBLE);
                }

            }
        });


        company.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                fragmentManager.beginTransaction()
//                        .replace(R.id.homeContainer, CategoryDetails.newInstance(trend.getImageUrl(), trend.getCompany(), "company", trend.getCommentType()), "categoryDetails")
//                        .addToBackStack("categoryDetails")
//                        .commit();

                CategoryDetails details = CategoryDetails.newInstance(trend.getImageUrl(), trend.getCompany(), "company", trend.getCommentType(),trend.getLocalcionUrl(),trend.getLng(),trend.getLat());
                details.setCls("close");

                UICreator.getInstance((AppCompatActivity) getActivity()).createDialog(details, "categoryDetails");
            }
        });


        profileInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UICreator.getInstance((AppCompatActivity) getActivity()).createDialog(ProfileDetails.newInstance(trend.getUser()), "acc");
//              UICreator.getInstance((AppCompatActivity) getActivity()).createDialog(details, "categoryDetails");
            }
        });
    }

    private void setUpTrend(Trend trend) {
        progressBar.setVisibility(View.GONE);
        body.setVisibility(View.VISIBLE);

        for (User u : trend.getLikes()) {
            if (u != null && u.getUid().equalsIgnoreCase(firebaseUser.getUid())) {
                changeIcon(R.drawable.heart, likeIc);
                like[0] = true;
            }
        }

        if (getContext() != null) {
            message.setText(trend.getComment());
            user.setText(trend.getUser().getUserName());
            company.setText(trend.getCompany());
            rating.setRating(Float.valueOf(trend.getRating()));
            Glide.with(getContext()).load(trend.getUser().getProfilePhotoUrl()).into(userProfile);
            if (trend.getImageUrl() != null & !trend.getImageUrl().isEmpty()) {
                Glide.with(getContext()).load(trend.getImageUrl()).into(imageView);
            } else {
                imageView.setVisibility(View.GONE);
            }
        }

        likesCount.setText(String.valueOf(trend.getLikes().size()));
    }

    private void setUpPageWithTrend(String id) {
        db.collection("riviws")
                .document(id).addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@javax.annotation.Nullable DocumentSnapshot documentSnapshot, @javax.annotation.Nullable FirebaseFirestoreException e) {
                if (documentSnapshot != null) {
                    Trend td = documentSnapshot.toObject(Trend.class);
                    if (td != null && isVisible()) {
                        setUpTrend(td);
                        likesCount.setText(String.valueOf(td.getLikes().size()));
                        Collections.reverse(td.getReplies());
                        updateRecycler(replyList, td.getReplies());
                        if (td.getLikes().size() > 1 || td.getLikes().size() == 0) {
                            likesMessage.setText("Likes");
                        } else {
                            likesMessage.setText("Like");
                        }
                    }
                }
            }
        });
    }


    @Override
    public void onStop() {
        super.onStop();
        navigationBtn.setVisibility(View.VISIBLE);
        dismissAllowingStateLoss();
    }

    @Override
    public void onStart() {
        super.onStart();
        navigationBtn.setVisibility(View.GONE);
    }

    @Override
    public void onPause() {
        super.onPause();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void updateRecycler(RecyclerView replyList, List<Reply> replys) {
        replyList.setAdapter(new RepliesAdapter(replys, getActivity(), getContext()));
        replyList.setLayoutManager(new LinearLayoutManager(getContext()));
    }


    private void likeCounter(final Trend reply) {
        ObjectMapper objectMapper = new ObjectMapper();
        DocumentReference ref = db.collection("riviws").document(reply.getId());
        Map<String, Object> likeUser = objectMapper.convertValue(getUser(), Map.class);

        if (like[0] == false) {

            ref.update("likes", FieldValue.arrayUnion(likeUser));
            likesCount.setText(String.valueOf(reply.getLikes().size() + 1));
            changeIcon(R.drawable.heart, likeIc);
            PostObjectHelper.getInstance().setAction(LIKED, reply.getId(), reply.getCompany(), reply.getUser().getUid());
            like[0] = true;
        } else {

            ref.update("likes", FieldValue.arrayRemove(likeUser));
            likesCount.setText(String.valueOf(reply.getLikes().size()));
            changeIcon(R.drawable.heart_outline, likeIc);
            PostObjectHelper.getInstance().unLike(reply);
            like[0] = false;
        }
    }

    private void changeIcon(int drawable, AppCompatImageView imageView) {
        assert getActivity() != null;
        try {
            imageView.setImageDrawable(getActivity().getResources().getDrawable(drawable));
        } catch (Resources.NotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
