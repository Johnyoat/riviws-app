package com.hipromarketing.riviws.constants;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.hipromarketing.riviws.models.User;

import javax.annotation.Nullable;

public class Constants {


    private static User user;
    public static final String DEFAULT = "Select Category";
    public static final String HOTELS = "Hotels";
    public static final String RESTAURANTS = "Restaurants";
    public static final String FASHION = "Fashion";
    public static final String HEALTH = "Health";
    public static final String NETWORK = "Network";
    public static final String TRIPS = "Trips";
    public static final String EDUCATION = "Education";
    public static final String AUTO_MOBILE = "Auto Mobile";
    public static final String TRAVELS = "Travels";
    public static final long RECYCLER_LOAD_TIME = 180;
    public static final String COMMENT = "commented on";
    public static final String LIKED = "liked";
    public static final String NOTIFICATION = "notification";
   public static final String SHOW_BANNER = "showbanner";
    public static final String API_VIDEO_DATA = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=UULUuqP5vBpWBNnUZUE32RLQ&key=AIzaSyBmW8Wm0il1LHAn95OjpQviD0dRJ-T4nto";


    public static User getUser() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        assert firebaseUser != null;
        db.collection("users").document(firebaseUser.getUid()).addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                if (documentSnapshot != null) {
                    user = documentSnapshot.toObject(User.class);
                }
            }
        });
        return user;
    }


    public static String setLocation(String placeId,String lng,String lat){
        return "https://www.google.com/maps/search/?api=1&query="+lat+","+lng+"&query_place_id="+placeId+"";
    }

}
